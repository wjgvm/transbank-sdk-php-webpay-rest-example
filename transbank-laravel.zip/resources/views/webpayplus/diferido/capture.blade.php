<h1>Webpay plus Diferido</h1>


<form action="post" action="">

      <label for="buy_order">Buy Order</label>
      <input id="buy_order" name="buy_order" value="123buyorder123">

      <label for="authorization_code">Authorization code</label>
      <input id="authorization_code" name="authorization_code" value={{ $authCode }} >

</form>
