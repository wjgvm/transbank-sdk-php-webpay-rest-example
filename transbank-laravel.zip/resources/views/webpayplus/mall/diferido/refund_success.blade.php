@extends('layout')
@section('content')
    <pre>{{ print_r($resp, true) }}</pre>
@endsection

