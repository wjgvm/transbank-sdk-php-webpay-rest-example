@extends('layout')
@section('content')
    <h1> Ejemplo Patpass Comercio-Voucher</h1>

<h3>Confirmacion Voucher:</h3>
<pre>
    El voucher fue generado exitosamente
</pre>

<a href="/">&laquo; Volver a index</a>
@endsection
